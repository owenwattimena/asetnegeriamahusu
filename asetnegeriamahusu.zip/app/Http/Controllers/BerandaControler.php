<?php

namespace App\Http\Controllers;

use App\Models\Aset;
use Illuminate\Http\Request;

class BerandaControler extends Controller
{
    public function index()
    {
        $data['totalAset'] = Aset::count();
        return view('beranda.index', $data);
    }
}

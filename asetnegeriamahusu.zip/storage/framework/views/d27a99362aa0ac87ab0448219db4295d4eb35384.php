<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--favicon-->
    <link rel="icon" href="assets/images/favicon-32x32.png" type="image/png" />
    <!--plugins-->
    <link href="<?php echo e(url('/')); ?>/assets/plugins/notifications/css/lobibox.min.css" rel="stylesheet" />
    <link href="<?php echo e(url('/')); ?>/assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <link href="<?php echo e(url('/')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="<?php echo e(url('/')); ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="<?php echo e(url('/')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
    <!-- loader-->
    <link href="<?php echo e(url('/')); ?>/assets/css/pace.min.css" rel="stylesheet" />
    <script src="<?php echo e(url('/')); ?>/assets/js/pace.min.js"></script>
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(url('/')); ?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/css/app.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/css/icons.css" rel="stylesheet">
    <!-- Theme Style CSS -->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/dark-theme.css" />
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/semi-dark.css" />
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/header-colors.css" />
    <title><?php echo e(Config::get('app.name', '')); ?> - <?php echo e(Config::get('app.description', 'default')); ?></title>
    <?php echo $__env->yieldContent('head'); ?>
</head>

<body>
    <!--wrapper-->
    <div class="wrapper">
        <!--start header wrapper-->
        <div class="header-wrapper">
            <!--start header -->
            <header>
                <div class="topbar d-flex align-items-center">
                    <nav class="navbar navbar-expand">
                        <div class="topbar-logo-header">
                            
                            <div class="">
                                <h4 class="logo-text ms-0" style="font-size:14px"><?php echo e(env('APP_NAME')); ?></h4>
                                <small><?php echo e(env('APP_DESCRIPTION')); ?></small>
                            </div>
                        </div>
                        <div class="mobile-toggle-menu"><i class='bx bx-menu'></i></div>
                        <div class="search-bar flex-grow-1">
                            
                        </div>
                        <div class="top-menu ms-auto">
                            <ul class="navbar-nav align-items-center">
                                <li class="nav-item mobile-search-icon">
                                    
                                </li>
                                <li class="nav-item dropdown dropdown-large">
                                    
                                </li>
                                <li class="nav-item dropdown dropdown-large">
                                    
                                    <div class="dropdown-menu dropdown-menu-end">
                                        
                                        <div class="header-notifications-list">
                                            
                                        </div>
                                        <a href="javascript:;">
                                            <div class="text-center msg-footer">View All Notifications</div>
                                        </a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown dropdown-large">
                                    
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="javascript:;">
                                            <div class="msg-header">
                                                <p class="msg-header-title">Messages</p>
                                                <p class="msg-header-clear ms-auto">Marks all as read</p>
                                            </div>
                                        </a>
                                        <div class="header-message-list">
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Daisy Anderson <span class="msg-time float-end">5 sec
                                                                ago</span></h6>
                                                        <p class="msg-info">The standard chunk of lorem</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-2.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Althea Cabardo <span class="msg-time float-end">14
                                                                sec ago</span></h6>
                                                        <p class="msg-info">Many desktop publishing packages</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-3.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Oscar Garner <span class="msg-time float-end">8 min
                                                                ago</span></h6>
                                                        <p class="msg-info">Various versions have evolved over</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-4.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Katherine Pechon <span class="msg-time float-end">15
                                                                min ago</span></h6>
                                                        <p class="msg-info">Making this the first true generator</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-5.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Amelia Doe <span class="msg-time float-end">22 min
                                                                ago</span></h6>
                                                        <p class="msg-info">Duis aute irure dolor in reprehenderit</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-6.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Cristina Jhons <span class="msg-time float-end">2 hrs
                                                                ago</span></h6>
                                                        <p class="msg-info">The passage is attributed to an unknown</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-7.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">James Caviness <span class="msg-time float-end">4 hrs
                                                                ago</span></h6>
                                                        <p class="msg-info">The point of using Lorem</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-8.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Peter Costanzo <span class="msg-time float-end">6 hrs
                                                                ago</span></h6>
                                                        <p class="msg-info">It was popularised in the 1960s</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-9.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">David Buckley <span class="msg-time float-end">2 hrs
                                                                ago</span></h6>
                                                        <p class="msg-info">Various versions have evolved over</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-10.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Thomas Wheeler <span class="msg-time float-end">2 days
                                                                ago</span></h6>
                                                        <p class="msg-info">If you are going to use a passage</p>
                                                    </div>
                                                </div>
                                            </a>
                                            <a class="dropdown-item" href="javascript:;">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-online">
                                                        <img src="assets/images/avatars/avatar-11.png" class="msg-avatar" alt="user avatar">
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        <h6 class="msg-name">Johnny Seitz <span class="msg-time float-end">5 days
                                                                ago</span></h6>
                                                        <p class="msg-info">All the Lorem Ipsum generators</p>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <a href="javascript:;">
                                            <div class="text-center msg-footer">View All Messages</div>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        
                        <?php if(auth()->guard()->check()): ?>
                        <div class="user-box dropdown">
                            
                                
                                <div class="user-info ps-3">
                                    <p class="user-name mb-0"><?php echo e(auth()->user()->nama); ?></p>
                                    <p class="designattion mb-0"><a href="<?php echo e(route('logout')); ?>"><i class='bx bx-log-out-circle'></i><span>Logout</span></a></p>
                                </div>
                            
                        </div>
                        <?php endif; ?>

                    </nav>
                </div>
            </header>
            <!--end header -->
            <!--navigation-->
            <div class="nav-container">
                <div class="mobile-topbar-header">
                    
                    <div>
                        <h4 class="logo-text ms-0" style="font-size:14px"><?php echo e(env('APP_NAME')); ?></h4>
                        <small><?php echo e(env('APP_DESCRIPTION')); ?></small>
                    </div>
                    <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
                    </div>
                </div>
                <nav class="topbar-nav" style="width: 100%">
                    <ul class="metismenu" id="menu">
                        <li> <a href="<?php echo e(url('/')); ?>">
                                <div class="parent-icon">
                                    <i class="bx bx-home-circle"></i>
                                </div>
                                <div class="menu-title">Beranda</div>
                            </a>
                        </li>
                        <?php if(auth()->guard()->check()): ?>
                        <li>
                            <a href="javascript:;" class="has-arrow">
                                <div class="parent-icon"><i class='bx bx-cog'></i>
                                </div>
                                <div class="menu-title">Master</div>
                            </a>
                            <ul>
                            <li> <a href="<?php echo e(route('master.satuan')); ?>"><i class="bx bx-right-arrow-alt"></i>Satuan</a>
                            </li>
                            <li> <a href="<?php echo e(route('master.kategori')); ?>"><i class="bx bx-right-arrow-alt"></i>Kategori</a>
                            </li>
                        </ul>
                        </li>
                        <li> <a href="<?php echo e(route('perencanaan')); ?>">
                                <div class="parent-icon">
                                    <i class="bx bx-pie-chart-alt-2"></i>
                                </div>
                                <div class="menu-title">Perencanaan Aset</div>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li> <a href="<?php echo e(route('aset')); ?>">
                                <div class="parent-icon">
                                    <i class="bx bx-list-ol"></i>
                                </div>
                                <div class="menu-title">Aset</div>
                            </a>
                        </li>
                        <?php if(auth()->guard()->check()): ?>
                        <li> <a href="<?php echo e(route('pengelolah')); ?>">
                                <div class="parent-icon">
                                    <i class="bx bx-user"></i>
                                </div>
                                <div class="menu-title">Pengelolah</div>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li> <a href="<?php echo e(route('pengelolahan')); ?>">
                                <div class="parent-icon">
                                    <i class="bx bx-user-plus"></i>
                                </div>
                                <div class="menu-title">Pengelolahan</div>
                            </a>
                        </li>

                    </ul>
                </nav>
            </div>
            <!--end navigation-->
        </div>
        <!--end header wrapper-->
        <!--start page wrapper -->
        <div class="page-wrapper">
            <div class="page-content">
                <?php if(session('alert')): ?>
                <div class="alert alert-<?php echo e(session('alert')['type']); ?> bg-<?php echo e(session('alert')['type']); ?> alert-dismissible fade show" role="alert">
                    <div class="text-white"><?php echo e(session('alert')['message']); ?></div>
                    <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <!--end page wrapper -->
        <!--start overlay-->
        <div class="overlay toggle-icon"></div>
        <!--end overlay-->
        <!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
        <!--End Back To Top Button-->
        <footer class="page-footer">
            <p class="mb-0">Copyright © 2021. All right reserved.</p>
        </footer>
    </div>
    <!--end wrapper-->
    <!--start switcher-->
    
    <!--end switcher-->
    <!-- Bootstrap JS -->
    <script src="<?php echo e(url('/')); ?>/assets/js/bootstrap.bundle.min.js"></script>
    <!--plugins-->
    <script src="<?php echo e(url('/')); ?>/assets/js/jquery.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/chartjs/js/Chart.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/chartjs/js/Chart.extension.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
    <!--notification js -->
    
    <script src="<?php echo e(url('/')); ?>/assets/js/index.js"></script>
    <!--app JS-->
    <script src="<?php echo e(url('/')); ?>/assets/js/app.js"></script>

    <?php echo $__env->yieldContent('script'); ?>
</body>

</html>
<?php /**PATH E:\laragon-php8\www\asetnegeriamahusu\resources\views/templates/index.blade.php ENDPATH**/ ?>
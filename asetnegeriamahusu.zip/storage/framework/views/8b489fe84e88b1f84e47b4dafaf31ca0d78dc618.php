<?php $__env->startSection('head'); ?>
<link href="<?php echo e(url('/')); ?>/assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <h6 class="mb-0 text-uppercase">Pengelolahan</h6>
        <hr />

        <div class="card">
            <div class="card-body">
                <?php if(auth()->guard()->check()): ?>

                <div class="text-end mb-3">
                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalKategori" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">Tambah</button>
                </div>
                <!-- Modal -->
                <div class="modal fade" id="modalKategori" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-md">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Tambah Pengelolahan</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('pengelolahan.create')); ?>" method="post">
                                <div class="modal-body">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-12">
                                        <label for="inputNama" class="form-label">Nama Pengelolah</label>
                                        <select class="form-control" id="inputNama" name="id_pengelolah">
                                            <?php $__currentLoopData = $pengelolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label for="inputAset" class="form-label">Nama Aset</label>
                                        <select class="form-control" id="inputAset" name="id_aset">
                                            <?php $__currentLoopData = $aset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_aset); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label for="inputTanggalMulai" class="form-label">Tanngal Mulai Kelolah</label>
                                        <input type="date" class="form-control" id="inputTanggalMulai" name="tanggal_mulai_kelolah">
                                    </div>
                                    <div class="col-12">
                                        <label for="inputTanggalSelesai" class="form-label">Tanggal Selesai Kelolah</label>
                                        <input type="date" class="form-control" id="inputTanggalSelesai" name="tanggal_selesai_kelolah">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-success">Tambah</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Pengelolah</th>
                                <th>Jabatan</th>
                                
                                <th>No Telp</th>
                                <th>Nama Barang</th>
                                <th>Jumlah</th>
                                <th>Tanggal Mulai Kelolah</th>
                                <th>Tanggal Selesai Kelolah</th>
                                <?php if(auth()->guard()->check()): ?>
                                <th>Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pengelolahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($item->pengelolah->nama); ?></td>
                                <td><?php echo e($item->pengelolah->jabatan); ?></td>
                                <td><?php echo e($item->pengelolah->no_telp); ?></td>
                                <td><?php echo e($item->aset->nama_aset); ?></td>
                                <td><?php echo e($item->aset->jumlah); ?></td>
                                <td><?php echo e($item->tanggal_mulai_kelolah); ?></td>
                                <td><?php echo e($item->tanggal_selesai_kelolah); ?></td>
                                <?php if(auth()->guard()->check()): ?>
                                <td>
                                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalKategoriEdit-<?php echo e($item->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"> <i class="bx bx-edit"></i> </button>
                                    <form action="<?php echo e(route('pengelolahan.delete', $item->id)); ?>" method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data?')"> <i class="bx bx-trash"></i> </button>
                                    </form>
                                </td>
                                <?php endif; ?>

                            </tr>
                            <!-- Modal -->
                            <div class="modal fade" id="modalKategoriEdit-<?php echo e($item->id); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-md">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Ubah Pengelolahan</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="<?php echo e(route('pengelolahan.update', $item->id)); ?>" method="post">
                                            <div class="modal-body">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <div class="col-12">
                                                    <label for="inputNama" class="form-label">Nama Pengelolah</label>
                                                    <select class="form-control" id="inputNama" name="id_pengelolah">
                                                        <?php $__currentLoopData = $pengelolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e($item->pengelolah->id == $val->id ? 'selected' : ''); ?> value="<?php echo e($val->id); ?>"><?php echo e($val->nama); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-12">
                                                    <label for="inputAset" class="form-label">Nama Aset</label>
                                                    <select class="form-control" id="inputAset" name="id_aset">
                                                        <?php $__currentLoopData = $aset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e($item->aset->id == $val->id ? 'selected' : ''); ?> value="<?php echo e($val->id); ?>"><?php echo e($val->nama_aset); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-12">
                                                    <label for="inputTanggalMulai" class="form-label">Tanngal Mulai Kelolah</label>
                                                    <input type="date" class="form-control" id="inputTanggalMulai" name="tanggal_mulai_kelolah" value="<?php echo e($item->tanggal_mulai_kelolah); ?>">
                                                </div>
                                                <div class="col-12">
                                                    <label for="inputTanggalSelesai" class="form-label">Tanggal Selesai Kelolah</label>
                                                    <input type="date" class="form-control" id="inputTanggalSelesai" name="tanggal_selesai_kelolah" value="<?php echo e($item->tanggal_selesai_kelolah); ?>">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-warning">Ubah</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end row-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/')); ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\asetnegeriamahusu\resources\views/pengelolahan/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="text-center">
    <img class="mb-3" src="<?php echo e(asset('assets/images/spanduk-aset.png')); ?>" width="80%" alt="">
</div>
<div class="row row-cols-1 row-cols-md-3 row-cols-xl-3 row-cols-xxl-3">
    <div class="col">
        <div class="card radius-10 bg-gradient-cosmic">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="me-auto">
                        <p class="mb-0 text-white">Total Aset</p>
                        <h4 class="my-1 text-white"><?php echo e($totalAset); ?></h4>
                    </div>
                    <div class="parent-icon" style="font-size: 50px;">
                        <i class="bx bx-list-ol text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col">
        <div class="card radius-10 bg-gradient-ibiza">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="me-auto">
                        <p class="mb-0 text-white">Total Pengelolah</p>
                        <h4 class="my-1 text-white">$84,245</h4>
                    </div>
                    <div class="parent-icon" style="font-size: 50px;">
                        <i class="bx bx-user text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col">
        <div class="card radius-10 bg-gradient-ohhappiness">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="me-auto">
                        <p class="mb-0 text-white">Total Aset Dikelolah</p>
                        <h4 class="my-1 text-white">34.6%</h4>
                    </div>
                    <div class="parent-icon" style="font-size: 50px;">
                        <i class="bx bx-user-plus text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\asetnegeriamahusu\resources\views/beranda/index.blade.php ENDPATH**/ ?>